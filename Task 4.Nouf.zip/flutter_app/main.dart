
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(RobotArmApp());
}

class RobotArmApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: RobotArmControl(),
    );
  }
}

class RobotArmControl extends StatefulWidget {
  @override
  _RobotArmControlState createState() => _RobotArmControlState();
}

class _RobotArmControlState extends State<RobotArmControl> {
  double motor1 = 0, motor2 = 0, motor3 = 0;

  Future<void> savePose() async {
    final url = Uri.parse("http://localhost/robot_arm/save_pose.php");
    await http.post(url, body: {
      'motor1': motor1.toString(),
      'motor2': motor2.toString(),
      'motor3': motor3.toString(),
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Robot Arm Control Panel")),
      body: Column(
        children: [
          Slider(
            value: motor1,
            min: 0,
            max: 180,
            divisions: 18,
            label: "Motor 1: ${motor1.round()}",
            onChanged: (value) => setState(() => motor1 = value),
          ),
          Slider(
            value: motor2,
            min: 0,
            max: 180,
            divisions: 18,
            label: "Motor 2: ${motor2.round()}",
            onChanged: (value) => setState(() => motor2 = value),
          ),
          Slider(
            value: motor3,
            min: 0,
            max: 180,
            divisions: 18,
            label: "Motor 3: ${motor3.round()}",
            onChanged: (value) => setState(() => motor3 = value),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(onPressed: savePose, child: Text("Save Pose")),
            ],
          ),
        ],
      ),
    );
  }
}
