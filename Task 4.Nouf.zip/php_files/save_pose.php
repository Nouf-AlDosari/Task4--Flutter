
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "robot_arm";
$conn = new mysqli($host, $user, $pass, $db);

$motor1 = $_POST['motor1'];
$motor2 = $_POST['motor2'];
$motor3 = $_POST['motor3'];

$conn->query("INSERT INTO poses (motor1, motor2, motor3) VALUES ($motor1, $motor2, $motor3)");

echo "Pose saved successfully.";
$conn->close();
?>
