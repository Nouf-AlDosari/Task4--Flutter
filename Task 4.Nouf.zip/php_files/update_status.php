
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "robot_arm";
$conn = new mysqli($host, $user, $pass, $db);

$id = $_POST['id'];

$conn->query("UPDATE poses SET status = 0 WHERE id = $id");

echo "Status updated.";
$conn->close();
?>
