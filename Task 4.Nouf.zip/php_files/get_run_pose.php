
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "robot_arm";
$conn = new mysqli($host, $user, $pass, $db);

$result = $conn->query("SELECT * FROM poses WHERE status = 1 LIMIT 1");

if ($result->num_rows > 0) {
    echo json_encode($result->fetch_assoc());
} else {
    echo json_encode(["message" => "No pose to run"]);
}
$conn->close();
?>
